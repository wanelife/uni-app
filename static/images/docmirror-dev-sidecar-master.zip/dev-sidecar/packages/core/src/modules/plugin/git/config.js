module.exports = {
  name: 'Git.exe代理',
  enabled: false,
  tip: '没有安装git.exe，不需要启动',
  setting: {
    sslVerify: true // 是否关闭sslVerify
  }
}
