# d2p-icon-select

## Props

<!-- @vuese:d2p-icon-select:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|value|值|`String`|`false`|''|
|placeholder|占位符|`String`|`false`|'请选择'|
|placement|弹出界面的方向|`String`|`false`|'right'|
|clearable|是否可清空|`Boolean`|`false`|true|
|userInput|是否允许用户输入|`Boolean`|`false`|false|
|autoClose|是否在选择后自动关闭|`Boolean`|`false`|true|

<!-- @vuese:d2p-icon-select:props:end -->


## Events

<!-- @vuese:d2p-icon-select:events:start -->
|Event Name|Description|Parameters|
|---|---|---|
|change|-|-|
|input|-|-|

<!-- @vuese:d2p-icon-select:events:end -->


