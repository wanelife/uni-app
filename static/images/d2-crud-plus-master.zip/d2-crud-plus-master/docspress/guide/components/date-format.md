# date-format

## Props

<!-- @vuese:date-format:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|value|日期时间值，支持long,string,date等，由dayjs转化|—|`true`|-|
|valueFormat|输入格式化，不传则由dayjs自动转化|—|`false`|-|
|format|输出格式化|—|`false`|'YYYY-MM-DD HH:mm:ss'|

<!-- @vuese:date-format:props:end -->


