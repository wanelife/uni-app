# d2p-button-input

## Props

<!-- @vuese:d2p-button-input:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|text|-|—|`false`|'点击'|
|elProps|el-input的配置，[el-input](https://element.eleme.cn/#/zh-CN/component/input)|`Object`|`false`|-|

<!-- @vuese:d2p-button-input:props:end -->


