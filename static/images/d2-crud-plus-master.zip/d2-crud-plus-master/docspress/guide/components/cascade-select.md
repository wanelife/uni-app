# cascade-select

## Props

<!-- @vuese:cascade-select:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|dict|数据字典<br/>{url:'xxx',data:[],value:'',label:'',children:''}|`Object`|`false`|[object Object]|
|value|值|—|`false`||
|elProps|el-cascader的属性,[el-cascader](https://element.eleme.cn/#/zh-CN/component/cascader)|`Object`|`false`|-|
|options|选项列表，优先级比dict高|`Array`|`false`|-|
|onReady|-|`Function`|`false`|-|

<!-- @vuese:cascade-select:props:end -->


