# text-area

## Props

<!-- @vuese:text-area:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|width|宽度，数字后面要带px|`String`|`false`|'100%'|
|rows|行数|`Number`|`false`|3|

<!-- @vuese:text-area:props:end -->


