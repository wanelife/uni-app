# d2p-wang-editor

## Props

<!-- @vuese:d2p-wang-editor:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|value|-|`String`|`false`|''|
|config|-|`Object`|`false`|-|
|uploader|-|`Object`|`false`|[object Object]|

<!-- @vuese:d2p-wang-editor:props:end -->


## Events

<!-- @vuese:d2p-wang-editor:events:start -->
|Event Name|Description|Parameters|
|---|---|---|
|change|-|-|
|input|-|-|

<!-- @vuese:d2p-wang-editor:events:end -->


