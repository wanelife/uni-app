# d2p-row-format

## Props

<!-- @vuese:d2p-row-format:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|value|接收row.xxx的值|`String`|`false`|-|
|color|-|—|`false`|-|

<!-- @vuese:d2p-row-format:props:end -->


