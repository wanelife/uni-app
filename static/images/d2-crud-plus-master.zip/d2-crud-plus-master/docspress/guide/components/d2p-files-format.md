# d2p-files-format

## Props

<!-- @vuese:d2p-files-format:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|value|值|—|`false`|-|
|color|颜色，【primary, success, warning, danger ,info】|—|`false`|'primary'|
|type|展示类型【text, tag】|—|`false`|'tag'|
|buildUrl|构建下载url方法|`Function`|`false`|function (value, item) {
  return value;
}|

<!-- @vuese:d2p-files-format:props:end -->


