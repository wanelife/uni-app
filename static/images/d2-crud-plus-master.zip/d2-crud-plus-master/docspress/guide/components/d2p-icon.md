# d2p-icon

## Props

<!-- @vuese:d2p-icon:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|value|icon名称|`String`|`false`|''|

<!-- @vuese:d2p-icon:props:end -->


