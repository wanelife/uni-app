# dict-radio

## Props

<!-- @vuese:dict-radio:props:start -->
|Name|Description|Type|Required|Default|
|---|---|---|---|---|
|dict|数据字典{url:'xxx',data:[],value:'',label:'',children:''}|`Object`|`false`|[object Object]|
|value|值|—|`false`|-|
|elProps|el-radio的配置，[el-radio](https://element.eleme.cn/#/zh-CN/component/radio#radio-attributes)|`Object`|`false`|-|
|options|选项列表，优先级比dict高|`Array`|`false`|-|
|type|按钮类型 [el-radio,el-radio-button]|`String`|`false`|'el-radio'|
|onReady|字典加载完成|`Function`|`false`|-|

<!-- @vuese:dict-radio:props:end -->


