# 字段类型默认配置参考
<<< @/packages/d2-crud-plus/src/lib/types/index.js