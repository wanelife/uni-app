# 他们在用

* [甘肃某门票分时预约及数据分析系统](https://tms.yougansu.com/orderManage/)
* [表格后台生成](https://cloud.battcn.com/)  crud配置从后台获取，通过后台配置即可生成crud表格  [开源地址](https://gitee.com/battcn/wemirr-platform)
* [ji-admin-ui](https://github.com/power4j/ji-admin-ui) , 配套后端[ji-admin](https://github.com/power4j/ji-boot)
* 还有很多的小伙伴做的是内部管理系统，没法分享出来    



