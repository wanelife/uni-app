module.exports = [
  {
    text: '指南',
    link: '/guide/'
  }
]
