# 配置: loading-options

## text

* 说明: 加载状态文案
* 类型: String
* 可选值: 无
* 默认值: 无

## spinner

* 说明: 加载状态图标类名
* 类型: String
* 可选值: 无
* 默认值: 无

## background

* 说明: 加载状态背景色值
* 类型: String
* 可选值: 无
* 默认值: 无
