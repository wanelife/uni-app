# 暴露的方法
以下是d2CrudX暴露的一些方法   

使用d2CrudPlus   
通过`this.getD2Crud().xxxx` 调用

未使用d2CrudPlus    
通过`this.$refs.d2Crud.xxxx`调用

<<< @/packages/d2-crud-x/src/mixin/exposeMethods.js


