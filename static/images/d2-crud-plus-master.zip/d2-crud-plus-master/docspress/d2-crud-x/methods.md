# 方法

## updateCell

* 说明: 更新单元格数据
* 参数: rowIndex,key,value

## addRow

* 说明: 新增行
* 参数: row

## updateRow

* 说明: 更新行
* 参数: index,row

## removeRow

* 说明: 删除行
* 参数: index

## showDialog
* 说明: 使用模态框新增或修改数据
* 参数: {mode,rowIndex,template}
* mode是必选参数，值为 'add' 和 'edit'，rowIndex和template为可选参数

## closeDialog
* 说明: 关闭模态框
* 参数: 无
