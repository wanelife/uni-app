# 开发环境

# 页面 title 前缀
VUE_APP_PUBLIC_PATH=/
VUE_APP_PATH=/
VUE_APP_API=/api/

VUE_APP_PM_ENABLED=true
# 关闭cdn
VUE_APP_NO_CDN=true
