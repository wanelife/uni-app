import { requestForMock } from '@/api/service'
// 请求模拟数据
const requestMock = requestForMock
// 使用 request 请求真实后端
// import { request } from '@/api/service'
export default requestMock
